//
//  ARViewController.h
//  UserDefinedTargets
//
//  Created by Lukasz Karluk on 19/05/13.
//
//

#import "ofxQCAR_ViewController.h"

@interface ARViewController : ofxQCAR_ViewController

@end
