//
//  ofxQCAR_App.h
//  UserDefinedTargets
//
//  Created by Lukasz Karluk on 19/05/13.
//
//

#pragma once

#include "ofMain.h"
#include "ofxiOS.h"
#include "ofxiOSExtras.h"

class ofxQCAR_App : public ofxiOSApp {

public:
    
    virtual void qcarInitialised() {
        // copy this method to your app to receive this callback.
    }
    
};
