//
//  ofxQCAREAGLView.h
//
//  Created by lukasz karluk on 19/01/12.
//

#import "ofxiOSEAGLView.h"
#import <QCAR/UIGLViewProtocol.h>

@interface ofxQCAR_EAGLView : ofxiOSEAGLView <UIGLViewProtocol> {
    //
}

@end